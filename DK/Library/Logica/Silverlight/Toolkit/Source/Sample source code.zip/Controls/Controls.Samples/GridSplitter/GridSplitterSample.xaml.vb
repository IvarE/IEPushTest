﻿' (c) Copyright Microsoft Corporation.
' This source is subject to the Microsoft Public License (Ms-PL).
' Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
' All other rights reserved.

Imports Microsoft.VisualBasic
Imports System
Imports System.ComponentModel

''' <summary>
''' Sample page demonstrating the GridSplitter.
''' </summary>
<Sample("GridSplitter", DifficultyLevel.Basic, "GridSplitter")> _
Partial Public Class GridSplitterSample
    Inherits UserControl
    ''' <summary>
    ''' Initializes a new instance of the DatePickerSample class.
    ''' </summary>
    Public Sub New()
        InitializeComponent()
    End Sub
End Class