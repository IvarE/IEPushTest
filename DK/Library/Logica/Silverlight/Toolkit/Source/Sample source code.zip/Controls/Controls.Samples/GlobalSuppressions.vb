﻿' (c) Copyright Microsoft Corporation.
' This source is subject to the Microsoft Public License (Ms-PL).
' Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
' All other rights reserved.

Imports System.Diagnostics.CodeAnalysis

<Assembly: SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Scope:="member", Target:="System.Windows.Controls.Samples.LayoutTransformerSample.#.ctor()")> 
<Assembly: SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Scope:="member", Target:="System.Windows.Controls.Samples.DragAndDropSample.#.ctor()")> 
<Assembly: SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Scope:="member", Target:="System.Windows.Controls.Samples.DemoChildWindow.#.ctor()")> 
<Assembly: SuppressMessage("Microsoft.Design", "CA1014:MarkAssembliesWithClsCompliant", Justification:="Silverlight requires the use of types that are not CLS compliant.")> 
'* Temporary *' 
<Assembly: SuppressMessage("Microsoft.Design", "CA1020:AvoidNamespacesWithFewTypes", Scope:="namespace", Target:="System.Windows.Controls.Samples")> 