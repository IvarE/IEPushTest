﻿' (c) Copyright Microsoft Corporation.
' This source is subject to the Microsoft Public License (Ms-PL).
' Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
' All other rights reserved.

''' <summary>
''' A Page that displays a variety of controls to which a frame can navigate.
''' </summary>
Public Class Page2
    Inherits Page

    ''' <summary>
    ''' Initializes a Page2.
    ''' </summary>
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
