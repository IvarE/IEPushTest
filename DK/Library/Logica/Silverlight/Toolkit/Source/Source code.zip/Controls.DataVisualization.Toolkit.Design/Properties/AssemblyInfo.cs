﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("System.Windows.Controls.DataVisualization.Toolkit.Design")]
[assembly: AssemblyDescription("Silverlight Toolkit Data Visualization Controls Design Time Assembly")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Microsoft® Silverlight™ Toolkit")]
[assembly: AssemblyCopyright("© Microsoft Corporation.  All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: NeutralResourcesLanguage("en-US")]
[assembly: ComVisible(false)]
[assembly: Guid("6385cd25-114c-4acf-83a7-f27100e07e1b")]
[assembly: AssemblyVersion("4.0.5.0")]
[assembly: AssemblyFileVersion("4.0.40413.2001")]