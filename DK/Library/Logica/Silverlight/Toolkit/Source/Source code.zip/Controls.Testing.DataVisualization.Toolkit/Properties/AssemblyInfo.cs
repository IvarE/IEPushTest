﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("System.Windows.Controls.Testing.DataVisualization.Toolkit")]
[assembly: AssemblyDescription("Unit Tests for System.Windows.Controls.DataVisualization.Toolkit")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Microsoft® Silverlight™ Toolkit")]
[assembly: AssemblyCopyright("© Microsoft Corporation.  All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: ComVisible(false)]
[assembly: Guid("b3a89968-1fdb-45bf-bf90-7610bc707f2a")]
[assembly: AssemblyVersion("5.0.5.0")]
[assembly: AssemblyFileVersion("5.0.60818.0")]