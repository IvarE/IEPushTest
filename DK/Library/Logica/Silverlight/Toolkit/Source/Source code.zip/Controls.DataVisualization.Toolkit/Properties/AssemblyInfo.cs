﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Silverlight-specific settings
[assembly: AssemblyDescription("Silverlight Toolkit Data Visualization Controls")]
[assembly: AssemblyVersion("5.0.5.0")]
[assembly: AssemblyFileVersion("5.0.60818.0")]
[assembly: AssemblyProduct("Microsoft® Silverlight™ Toolkit")]
[assembly: Guid("5d0880cb-44d8-4a5c-a839-e7bd88ce022d")]

// Silverlight-only settings
